package com.googlecode.videosplitter.mpeg.atom;

@SuppressWarnings("serial")
public class AtomError extends RuntimeException {
  public AtomError(String msg) {
    super(msg);
  }
}
